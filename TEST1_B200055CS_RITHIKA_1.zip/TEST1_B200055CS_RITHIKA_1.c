#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
void read_students(char* A,int n){
    for(int i=0;i<n;i++)
     scanf(" %c",&A[i]);
}

void print_students(char*A, int n){
    
    for(int i=0;i<n;i++){
        printf("%c ",A[i]);
    }

    printf("\n");
}


  void arrange_students(char*A,int n){
  int p_caps[10000];
  int ascii=90;
  int j=0;
  int o=0;
  //merge_sort(A,0,n-1);
  for(int i=ascii;i>=65;i--){
      if(A[o++]==ascii)
       p[j++]=A[i];
    if(ascii==65)
    o=0;
  }
 int o=0;

  int p_1[10000];

  int j_1=0;
   for(int i=122;i>=97;i--){
      if(A[o++]==i)
       p_1[j_1++]=A[i];

      if(ascii==65)
       o=0;
  }

  int g[10000];

  g[0]=p_1[0];
  int g_1=1;

  for(int k=0, l=0;k<j,p<j_1;){
     if(p[k]<p_1[l] && p_1[l]=p[k]+32){
         g[g_1++]=p[k++];
     }
     else  g[g_1++]=p[l++];
     
  }

 
}


int main(){
    char* A;
    char ch;
    int n=0;
    while(1){
        scanf("%c",&ch);

        switch(ch){
             case 'r': scanf("%d",&n);
                       A=(char*)malloc(n*sizeof(char));
                       read_students(A,n);
                       break;

              case 'p': print_students(A,n);
                        break;

              case 'a': arrange_students(A,n);
                        break;

              
            
              case 't': return 1;

        }
    }

    return 0;
}