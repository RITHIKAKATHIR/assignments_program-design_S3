#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
void read_students(char* A,int n){
    for(int i=0;i<n;i++)
     scanf(" %c",&A[i]);
}

void print_students(char*A, int n){
    
    for(int i=0;i<n;i++){
        printf("%c ",A[i]);
    }

    printf("\n");
}

int partition(char*A,int start,int end,int v1){
    int pivot;
    int trans;
    pivot=v1;
    int i=start;
    int j;
    for(j=start;j<=(end-1);j++){
        if(A[j]<=pivot){
            trans=A[j];
            A[j]=A[i];
            A[i]=trans;
            i++;
        }
       
    }

    int fin;
    fin=A[i];
    A[i]=pivot;
    A[j]=fin;


    return i;
}


void quicksort(char* A_1,int start_1,int end_1,int v){
 if(start_1<end_1){
    int q;
    q=partition(A_1,start_1,end_1,v);
    quicksort(A_1,start_1,q-1,v);
    quicksort(A_1,q+1,end_1,v);
  }
}

void divide_students(char*A, int n, int rval){
  quicksort(A,0,n,rval);
}
int flag=0;

void list_students(char* A,int n,char c){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(A[i]==c){
            printf("%d",i);
            flag=1;
        }
    }
}
if(flag!=1){
    printf("%d",-1);
}
}
int main(){
    char* A;
    char ch;
    int n=0;
    int rval;
    int pos;
    char c;
    while(1){
        scanf("%c",&ch);

        switch(ch){
             case 'r': scanf("%d",&n);
                       A=(char*)malloc(n*sizeof(char));
                       read_students(A,n);
                       break;

              case 'p': print_students(A,n);
                        break;

             case 'd': scanf("%d",&rval);
                        divide_students(A,n,rval);
                        break;

              //case 'a': arrange_students(A,n,pos);
                        //break;

             case 'l': scanf(" %c",&c);
                       list_students(A,n,c);
                       break;

             case 't': return 1;

        }
    }

    return 0;
}
